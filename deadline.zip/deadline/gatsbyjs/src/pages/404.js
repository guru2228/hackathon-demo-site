import React from 'react';

function ErrorPage() {
  return <div>Page Not Found</div>;
}

export default ErrorPage;
